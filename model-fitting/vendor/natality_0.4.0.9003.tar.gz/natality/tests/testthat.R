library(testthat)
library(natality)

test_check("natality")
